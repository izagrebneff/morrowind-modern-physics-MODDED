OpenMW 0.52 NPC and creature blood decals
84 original placeholders, 64x64 indexed PNG with transparency.
Put textures/npc_blood/ in a data directory loaded after other mods. Keep the names.
01-04 slash/chop; 05-08 small; 09-12 large/power.
Red, dark, blue, green, orange, gold, white; no energy stains.
No Dark Messiah or third-party images included.
Use RGBA PNG for replacements (alpha controls stain). Restart OpenMW after replacing.
